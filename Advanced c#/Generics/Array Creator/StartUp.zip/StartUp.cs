﻿using System;
using Array_Creator;

namespace GenericArrayCreator
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] strings = ArrayCreator.Create(5, "Pesho");
            foreach (var name in strings)
            {
                Console.WriteLine(name);
            }
        }
    }
}
